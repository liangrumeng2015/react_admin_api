## 项目描述
该项目主要是用来写react-admin_client写接口的。

## 接口文件
readme.txt文件里面