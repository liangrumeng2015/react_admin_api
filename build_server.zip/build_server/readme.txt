接口文档：
（1）登录接口：
post请求   /api/login.do
参数：
    username  # 用户名
    password  # 密码

（2）获取天气接口：
get请求  /api/weather.do
参数：
    version  #v1或者v6免费接口
    city  #城市名称

（3）获取category列表：
get请求：
    /api/category/getCategoryList.do

（4）添加分类：
post请求 /api/category/addCategory.do


(5)商品列表：
post请求：/api/product/getProductsList.do