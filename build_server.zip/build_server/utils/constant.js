const APPID = 'wxedc02b50e390dce8';
const SECRET = '3ff4747eb7c5b6f6ae2bd16e431a14e9';

module.exports = {APPID,SECRET}